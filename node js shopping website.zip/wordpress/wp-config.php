<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ahmad-portfolio' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'qLN]NZF.Pa7;7m,-hj~ya3>%KM{Mk`={|K.Dsb7ZKUL^8%e(()RkWWcj|Q25h[#`' );
define( 'SECURE_AUTH_KEY',  '+j}l#Ub+OEJD{058j{>^%Z_S`fTqA<!J^a/:?o@x{n`quS-FQ8VOLb=V8^?{by;W' );
define( 'LOGGED_IN_KEY',    'iv|i)6o7}#u*_%EDxt(qw)<HvY]i_ZCi[kw^.l H4[b4/.vCYU;lX7?Po-k,:0!P' );
define( 'NONCE_KEY',        'GS0oKix%=O>:,wl46AoGTBlW)tuEq;j,]?!5@bsC[eMN}Z)fAB7ZPX&K7c;$)^R!' );
define( 'AUTH_SALT',        ';Q@j{|>p<0z}o03B~)p}bGZZmD6arEZ6<Q0y{AF<7CKuEzJ%[Tn11zI4d3.YJL7n' );
define( 'SECURE_AUTH_SALT', '0/byR5K*PWZ~*xkt4eS^dOQ$q^u_ebm/=_fx) `Oiy1R~IL<6`hq@G9&$czW|;Gm' );
define( 'LOGGED_IN_SALT',   '!k$*kUPDlhr!NwdybOb{p(q@XL0+G}=,xa6t%3Qehg7W~B *MpY)R^lYp}W0StNb' );
define( 'NONCE_SALT',       'Ff&I6Q_/LVk`XI.uY8*_;vV|C#Pj|uEeL/(g+vj:*}rpBYaZG,HX ,GIu%,,^wLZ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
